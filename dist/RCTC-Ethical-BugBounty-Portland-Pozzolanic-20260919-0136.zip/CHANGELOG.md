# Changelog

## [Unreleased] — Ethical Bug-Bounty Training (Portland–Pozzolanic)

### Added
- Bilingual ethical bug-bounty track under `tracks/bug-bounty/` (EN+AR, modules 00–05)
- Scope Guard + track validator with intentional invalid fixtures
- Capability `ethical-bugbounty-training` (side_effect none, network false, STOP/GAP)
- Pro Coffee Pass pedagogy layer under `tracks/bug-bounty/pro/`
- Packaging proposal + SAFETY_MODEL + IMPLEMENTATION_REPORT
- RCTC-SKILLS motto: ليست كل الحكم تصلح دائماً ولكن من طلب العلى سهر الليالي ^_^

All notable changes to RCTC Method will be documented here.

## [1.0.0] — Initial Release

### Added
- Core RCTC analysis engine (Role, Context, Task, Constraints detection)
- Smart question system — one question at a time, with reasoning
- Template system for Arabic and English responses
- User learning & adaptation system
- Horizontal skill recommendation engine
- Configuration system (`config.yaml`)
- Full documentation suite
- Arabic and English example libraries

### Philosophy
- Component detection based on engineering judgment, not mechanical checklist
- Transparency: always explain why a question is being asked
- Respect user's time: never ask what context makes obvious

---

## [1.0.1] — Documentation

### Added
- `docs/launch-kit.md` — copy-paste posts for LinkedIn, Reddit, WhatsApp/Telegram
- README Pro section + GitHub Discussions early-access link

---

## [Planned — 1.1.0]

- IDE integration guides (Cursor, VS Code, JetBrains)
- Web-based prompt builder UI
- Shared team profiles
- Analytics dashboard
- Skill marketplace integration
