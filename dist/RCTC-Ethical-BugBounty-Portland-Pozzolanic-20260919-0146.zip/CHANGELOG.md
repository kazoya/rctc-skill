# Changelog

## [Unreleased] — Ethical Bug-Bounty Training (Portland–Pozzolanic)

> Track status: **Unreleased**. Root `SKILL.md` remains `version: 1.0.0`. This is not a stable 1.1 / 1.1.0-rc product release.

### Added
- Bilingual ethical bug-bounty track under `tracks/bug-bounty/` (EN+AR, modules 00–05)
- Scope Guard (declaration-only decisions) + track validator + fixtures
- Capability `ethical-bugbounty-training` (`release_state: unreleased`)
- Public Pro catalog `tracks/bug-bounty/pro/README.md` + Coffee Pass pointers (no Pro lesson bodies in MIT tree)
- Multi-track extension point `tracks/README.md` (future competition labs not implemented)
- RCTC-SKILLS motto

### Changed (pre-push)
- Renamed `AUTHORIZED_FOR_DECLARED_ACTIVITY` → `DECLARED_SCOPE_CONTEXT_ACCEPTED`
- Explicit `authorization_verified_by_rctc: false` and human confirmation for declared live targets
- Removed supporter-only Pro lesson files from the public tree

## [1.0.0] — Initial Release

### Added
- Core RCTC analysis engine (Role, Context, Task, Constraints detection)
- Smart question system — one question at a time, with reasoning
- Template system for Arabic and English responses
- User learning & adaptation system
- Horizontal skill recommendation engine
- Configuration system (`config.yaml`)
- Full documentation suite
- Arabic and English example libraries

### Philosophy
- Component detection based on engineering judgment, not mechanical checklist
- Transparency: always explain why a question is being asked
- Respect user's time: never ask what context makes obvious

---

## [1.0.1] — Documentation

### Added
- `docs/launch-kit.md` — copy-paste posts for LinkedIn, Reddit, WhatsApp/Telegram
- README Pro section + GitHub Discussions early-access link

---

## [Planned — 1.1.0]

- IDE integration guides (Cursor, VS Code, JetBrains)
- Web-based prompt builder UI
- Shared team profiles
- Analytics dashboard
- Skill marketplace integration
