# Risks

1. **Compose name drift** — recipe `compose` strings may not exactly match `registry/skills.json` ids (CLI reports gaps; does not invent skills).
2. **Plan ≠ build** — architecture for build/publish stages exists in recipes; CLI does not execute them (by design). Missing execution path is intentional until owner-gated runner exists.
3. **Master Brain platform** vs HQ folder — registration is in `C:\\master` files; `C:\\master-brain` UI may need a separate import if used as source of truth.
4. **PowerShell quoting** on Windows builder — prefer `cmd /c` + Node scripts.
5. **Project1 unpushed commits** — local may be ahead of origin; this loop did not force-push Project1.
