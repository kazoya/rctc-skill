# Test results — 2026-09-19

## Project1
- typecheck before: exit 0
- typecheck after: exit 0

## DPF
- validate-recipes: {"name":"validate-recipes","exit":0,"out":"OK company-marketing-site\nOK factory-sales-concept\nOK personal-engineering-portfolio\nOK product-showcase\nOK project-evidence-portal\nOK technical-delivery-portfolio\nRECIPES_VALID\n"}
- dogfood runs: 4
  - portfolio: exit 0
  - factory-sales-concept: exit 0
  - project1-safe: exit 0
  - master-safe: exit 0

## Notes
Full dogfood transcripts: `dogfood-*.txt` beside this zip staging on the builder machine; key excerpts included under `dogfood/` in the zip.
