# Next candidates (smallest high-leverage)

1. Owner-gated `dpf run --stage build` that executes compose chain without publish
2. Normalize recipe compose ids 1:1 with registry
3. Import Master capability JSON into master-brain UI if that is the live catalog
4. Publish community Discussion from draft after owner edit
5. Promote `compose-first-skill-gate` only after Validate→Review→Test
