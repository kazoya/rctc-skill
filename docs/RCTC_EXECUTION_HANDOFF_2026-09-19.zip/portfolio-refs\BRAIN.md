# العقل الهندسي — محفظة صهيب عسراوي — الموقع العام / Suhib Asrawi public portfolio site

> ملف مُولَّد تلقائياً من `brain.json` + `journal/` — لا تعدّله يدوياً؛ استخدم `mb brain` / `mb log` أو أدوات MCP.

- **ID:** `suhib-portfolio`  |  **الحالة:** مفتوح / Open  |  **التقدّم:** 92%  |  **الأولوية:** 2
- **آخر تحديث:** 2026-09-17 07:58

## ✓ ما تم إنجازه / Done

- إعادة تموضع المحفظة حول رحلة «من DOS إلى وكلاء الذكاء الاصطناعي»: صفحة /journal بعشرة فصول وذاكرات هندسية وطريقة وأجيال تقنية ونظرة مسؤول توظيف ووضع أصحاب أعمال وخمسة مدخلات هندسية وقسم أمن تطبيقي (PortSwigger 273/273). Playwright 145/145، axe 0، Lighthouse جوال 91–93 وسطح مكتب 100. منشور على Vercel. — _Claude Fable_ <sub>2026-09-17 · `b-a979ee2f`</sub>
- /en صفحة إنجليزية LTR حقيقية بترويسة وتذييل ولوحة أوامر إنجليزية وسيرة قابلة للطباعة؛ hreflang في الاتجاهين؛ H1 واحد وcanonical ذاتي وOG لكل صفحة؛ JSON-LD Person/WebSite/ProfilePage/SoftwareApplication. — _Claude Fable_ <sub>2026-09-17 · `b-ebc04f51`</sub>
- سيرة A4 من السيرة PDF المعتمدة (2026-09-16) بلا عبارات «أضف قبل الإرسال»؛ أكاديمية APCA موسومة «مُظهِر مقترح متوافق مع أهداف GIZ»؛ 35 رابط Vercel حيّاً متحقق منها؛ روابط مستقل ولينكدإن مصحّحة. — _Claude Fable_ <sub>2026-09-17 · `b-9a4ef5a3`</sub>
- طبقة مؤثرات خلف علم NEXT_PUBLIC_EFFECTS: ساعة عمّان، حقل عقد Canvas، شريط قراءة؛ 24 اختباراً؛ 4.3 KB gzip؛ مدمجة بموافقة المالك. — _Claude Fable_ <sub>2026-09-17 · `b-81a34493`</sub>
- اعتماد تحسينين من الوكيل الخارجي: scripts/verify-public-assets.mjs داخل بوابة npm run verify (يفشل مبكراً عند صورة مفقودة أو فارغة مشار إليها من data/)، وتثبيت خادم Playwright على 127.0.0.1 للحاويات المقيدة. البوابات خضراء 145/145. commit be503f1. — _Claude Fable_ <sub>2026-09-17 · `b-9b847bfa`</sub>
- دورة update-zip-skill مفعّلة على المحفظة (profile portfolio-site): حزمة الاستشارة الأولى في Downloads/portfolio-consult-*.zip، والاستيعاب يذهب إلى فرع improve/* ببوابة verify ولا يكتب في main. — _Claude Fable_ <sub>2026-09-17 · `b-1f2079e3`</sub>

## ◎ ما توصلنا إليه / Findings & conclusions

- Next.js يستبدل كائن openGraph المتداخل بدل دمجه؛ كل صفحة يجب أن تنشر قاعدة OG مشتركة (lib/seo.ts: ogAr/ogEn). صور OG بالملفات لا تُحقن حين تعرّف الصفحة openGraph، فصارت مسارات /og و/og/projects/[id]. — _Claude Fable_ <sub>2026-09-17 · `b-00d823ae`</sub>
- تقييم axe يفشل زوراً على عناصر .reveal ذات opacity 0 قبل التقاطع؛ التشغيل بـ prefers-reduced-motion يعطي القيم الحقيقية. — _Claude Fable_ <sub>2026-09-17 · `b-72be9c12`</sub>
- تصدير المنصة القديم قال 6 روابط حيّة بينما لوحة Vercel تُظهر 35؛ الرقم العام يجب أن يأتي من تحقق HTTP مؤرخ لا من تصدير قديم. — _Claude Fable_ <sub>2026-09-17 · `b-09227e74`</sub>
- حزمة التطوير الأولى (2026-09-17) كانت ناقصة: قاعدة استثناء المجلدات (journal، screenshots) حذفت أيضاً app/(ar)/journal وapp/(en)/en/journal وpublic/screenshots، فبنى الوكيل الخارجي 49 صفحة بدل 51. أُصلح المولّد ليستثني المجلدين على جذر المستودع فقط. — _Claude Fable_ <sub>2026-09-17 · `b-55c204f3`</sub>

## ◐ ما نعمل عليه حالياً / In progress now

- لا عمل جارٍ. الموقع مستقر على commit main الأخير. — _Claude Fable_ <sub>2026-09-17 · `b-176ba5d8`</sub>

## ▹ الخطوات التالية / Next steps

- قرار المالك: نشر رقم الهاتف (owner.publicPhone). — _Claude Fable_ <sub>2026-09-17 · `b-1156c187`</sub>
- نسخة عامة مخفّفة من Project1 (README + مخطط + ملف اختبار) لتصبح أقوى محاكاة مرئية. — _Claude Fable_ <sub>2026-09-17 · `b-7b7176bf`</sub>
- لقطات داخلية إضافية لكل دراسة حالة، وترجمة دراسات الحالة إلى /en/projects إن صار الجمهور الإنجليزي أساسياً. — _Claude Fable_ <sub>2026-09-17 · `b-db320ec2`</sub>
- مدة حل مختبرات PortSwigger تنتظر تاريخي البدء والانتهاء من المالك. — _Claude Fable_ <sub>2026-09-17 · `b-b3e3bda3`</sub>

## ▲ ما نتطلع إلى تحسينه / Improvements we aim for

_لا شيء بعد._

## ✦ مقترحات النماذج (Claude / Opus / Fable…) / Model suggestions (Claude / Opus / Fable…)

- إضافة اختبار Playwright يفتح الموقع الحي بعد كل نشر (smoke على Vercel) بدل الاعتماد على curl يدوي. — _Claude Fable_ [proposed] <sub>2026-09-17 · `b-f9caca65`</sub>

## ◆ القرارات المعتمدة / Decisions

_لا شيء بعد._

## ⊘ العوائق / Blockers

_لا شيء بعد._

## ≡ القيود والقواعد / Constraints & rules

- لا أرقام أو عملاء أو شهادات أو تواريخ مخترعة؛ السنوات الأولى بلا تواريخ عمداً؛ لا ادعاء شهادة BSCP؛ لا موافقة GIZ؛ الوكلاء أداة تحت قيود مكتوبة والقرار للمالك. — _Claude Fable_ <sub>2026-09-17 · `b-535209cc`</sub>
- بوابة القبول: npm run verify أخضر + axe 0 serious + Lighthouse جوال ≥ 90 + CLS 0؛ لا نشر ولا تعديل Vercel/GitHub من وكيل خارجي. — _Claude Fable_ <sub>2026-09-17 · `b-cc360ad3`</sub>

## 🗓️ آخر مدخلات سجل التقدّم

- ↗ **2026-09-17 10:13** — ⌨️ Claude Code: مهمة فحص قصيرة جداً: اكتب سطر PROGRESS: 20% — بدأت. ثم نفّذ أمر Bash و — _Claude (generic)_ · `journal/20260917-1013-claude-code-مهمة-فحص-قصيرة-جداً-اكتب-سطر-edf4.md`
- ↗ **2026-09-17 07:58** — update-zip-skill applied (portfolio-site profile): consult pack built, ingest dry-run green (92%) — _Claude Fable_ · `journal/20260917-0758-update-zip-skill-applied-portfolio-site--52ab.md`
- ↗ **2026-09-17 07:40** — External agent review adopted (asset check + Playwright host); dev pack rebuilt complete (91%) — _Claude Fable_ · `journal/20260917-0740-external-agent-review-adopted-asset-chec-71ec.md`
- ✦ **2026-09-17 07:05** — تسجيل المحفظة في Master Brain بعد إعادة البناء الكاملة والنشر (90%) — _Claude Fable_ · `journal/20260917-0705-تسجيل-المحفظة-في-master-brain-بعد-إعادة--85a0.md`
