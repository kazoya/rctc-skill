# Master HQ — Discoverable Capabilities

Registration is **metadata only**. Listing a capability here must **execute nothing**.

| id | summary | invoke | side-effect on register | owner gates |
|---|---|---|---|---|
| `digital-presence-factory` | Compose RCTC skills into a digital-presence plan (portfolio / factory / evidence portal) | `node C:/rctc-skill/digital-presence-factory/cli.js --type … --source …` | none | deploy, push, publish skill, buyHalt changes |

Details: `files/capabilities/digital-presence-factory.json`
