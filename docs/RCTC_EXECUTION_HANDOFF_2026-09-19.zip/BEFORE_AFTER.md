# Before / After evidence

## Before
```json
{
  "project1": {
    "label": "before",
    "path": "C:\\project1",
    "exists": true,
    "git": "7288ea18a366b2b90e47d9d02e79682f3005c257",
    "status": "## main...origin/main [ahead 2]\n?? .mcp.json\n?? \"New Text Document.txt\"\n?? browse_api.json\n?? docs/CEO_CLAUDE_RUN_2026-09-18.log\n?? docs/CEO_CLAUDE_SONNET_RUN_2026-09-18.log\n?? docs/CEO_CLAUDE_TASK.txt\n?? docs/CEO_STATUS_2026-09-18.md\n?? docs/Project1-Production-Armed-Pack-2026-09-16.zip\n?? docs/Project1_2026_Portland_Pozzolan_Execution_Pack.zip\n?? docs/Project1_2026_Portland_Pozzolan_Execution_Pack/\n?? docs/Project1_AI_Handoff_Full_Pack.zip\n?? docs/Project1_Consult_Pack_2026-09-18.zip\n?? docs/Project1_Execution_Pack_V2.zip\n?? docs/Project1_Execution_Pack_V2/\n?? docs/Project1_External_Improvement_Pack_2026-09-18.zip\n?? docs/Project1_Google_Login_And_Discovery_Pack.zip\n?? docs/RCTC_PHASE2_LIGHTSPEED_GITHUB_GROWTH_2026-09-18.zip\n?? docs/brain/PROJECT1_MAX_SPEED_OWNER_PROMPT.md\n?? docs/owner-google-discovery-pack/\n?? docs/owner/\n?? docs/run-ceo-claude-sonnet.js\n?? docs/run-ceo-claude.js\n?? tests/quote-compare-route.test.ts",
    "typecheck": {
      "exit": 0,
      "tail": ""
    },
    "buyHaltMentions": [
      "search_note: spawnSync C:\\WINDOWS\\system32\\cmd.exe ENOBUFS"
    ]
  },
  "master": {
    "label": "before",
    "path": "C:\\master",
    "exists": true,
    "top": [
      ".agents",
      ".claude",
      ".codex",
      ".cursor",
      ".git",
      ".gitignore",
      "AGENTS.md",
      "brain.json",
      "BRAIN.md",
      "bridge",
      "CLAUDE.md",
      "CODEX.md",
      "files",
      "journal",
      "package.json",
      "project.json",
      "prompts",
      "README.md",
      "ROLES.md",
      "scripts",
      "SOURCES.md"
    ],
    "hasRoles": true,
    "hasProject": true,
    "hasCapabilities": false
  }
}
```

## After
```json
{
  "project1": {
    "label": "after",
    "path": "C:\\project1",
    "exists": true,
    "git": "7288ea18a366b2b90e47d9d02e79682f3005c257",
    "status": "## main...origin/main [ahead 2]\n?? .mcp.json\n?? \"New Text Document.txt\"\n?? browse_api.json\n?? docs/CEO_CLAUDE_RUN_2026-09-18.log\n?? docs/CEO_CLAUDE_SONNET_RUN_2026-09-18.log\n?? docs/CEO_CLAUDE_TASK.txt\n?? docs/CEO_STATUS_2026-09-18.md\n?? docs/Project1-Production-Armed-Pack-2026-09-16.zip\n?? docs/Project1_2026_Portland_Pozzolan_Execution_Pack.zip\n?? docs/Project1_2026_Portland_Pozzolan_Execution_Pack/\n?? docs/Project1_AI_Handoff_Full_Pack.zip\n?? docs/Project1_Consult_Pack_2026-09-18.zip\n?? docs/Project1_Execution_Pack_V2.zip\n?? docs/Project1_Execution_Pack_V2/\n?? docs/Project1_External_Improvement_Pack_2026-09-18.zip\n?? docs/Project1_Google_Login_And_Discovery_Pack.zip\n?? docs/RCTC_PHASE2_LIGHTSPEED_GITHUB_GROWTH_2026-09-18.zip\n?? docs/brain/PROJECT1_MAX_SPEED_OWNER_PROMPT.md\n?? docs/owner-google-discovery-pack/\n?? docs/owner/\n?? docs/run-ceo-claude-sonnet.js\n?? docs/run-ceo-claude.js\n?? tests/quote-compare-route.test.ts",
    "typecheck": {
      "exit": 0,
      "tail": ""
    },
    "buyHaltMentions": [
      "search_note: spawnSync C:\\WINDOWS\\system32\\cmd.exe ENOBUFS"
    ]
  },
  "master": {
    "label": "after",
    "path": "C:\\master",
    "exists": true,
    "top": [
      ".agents",
      ".claude",
      ".codex",
      ".cursor",
      ".git",
      ".gitignore",
      "AGENTS.md",
      "brain.json",
      "BRAIN.md",
      "bridge",
      "CAPABILITIES.md",
      "CLAUDE.md",
      "CODEX.md",
      "files",
      "journal",
      "package.json",
      "project.json",
      "prompts",
      "README.md",
      "ROLES.md",
      "scripts",
      "SOURCES.md"
    ],
    "hasRoles": true,
    "hasProject": true,
    "hasCapabilities": true,
    "hasDpfCap": true
  }
}
```

## Invariants
- Project1 purchasing / buyHalt / Dry Run: **not modified** this loop
- DPF CLI: **plan only** — no deploy
- Master registration: **metadata only**
